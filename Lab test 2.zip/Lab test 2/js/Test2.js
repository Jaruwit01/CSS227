function Hide () {
    document.getElementById('square').classList.add('hide');
}
function Show () {
    document.getElementById('square').classList.remove('hide');
}
function Left () {
    
}